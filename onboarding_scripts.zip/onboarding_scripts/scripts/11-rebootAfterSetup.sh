#!/bin/bash
#set -x

# Script Configuration
secondsToWaitForOtherApps=3600
appname="Redémarrage"

# Define log and start logging...
log="/var/tmp/rebootAfterSetup.log"
exec &> >(tee -a "$log")

dockapps=(  "/Applications/Microsoft Edge.app"
            "/Applications/Microsoft Outlook.app"
            "/Applications/Microsoft Word.app"
            "/Applications/Microsoft Excel.app"
            "/Applications/Microsoft PowerPoint.app"
            "/Applications/Microsoft OneNote.app"
            "/Applications/Microsoft Teams.app"
            "/Applications/Company Portal.app"
            "/Library/Application Support/Microsoft/MAU2.0/Microsoft AutoUpdate.app"
            "/Applications/GlobalProtect.app"
            "/Applications/Adobe Acrobat Reader.app"
            "/Applications/connectwisecontrol-5f08c78d39db1f7f.app"
            "/Applications/Microsoft Remote Desktop.app"
            "/Applications/Microsoft Remote Help.app"
            "/Applications/LansweeperAgent/LsAgent"
            "/usr/local/bin/dockutil")

echo ""
echo "##############################################################"
echo "# $(date) | Starting install of $appname"
echo "############################################################"
echo ""

# Function to update Swift dialog
function updateSplashScreen () {

    #################################################################################################################
    #################################################################################################################
    ##
    ##  This function is designed to update the Splash Screen status (if required)
    ##
    ###############################################################
    ###############################################################


    # Is Swift Dialog present
    if [[ -a "/Library/Application Support/Dialog/Dialog.app/Contents/MacOS/Dialog" ]]; then


        echo "$(date) |     Updating Swift Dialog monitor for [$appname] to [$1]"
        echo listitem: title: $appname, status: $1, statustext: $2 >> /var/tmp/dialog.log 

        # Supported status: wait, success, fail, error, pending or progress:xx

    fi

}


START=$(date +%s) # define loop start time so we can timeout gracefully
echo "$(date) | Looking for required applications..."

# Check if the machine has rebooter after initial setup (added by Steven Deblois)
if [[ -a "/var/tmp/rebootedAfterSetup" ]]; then

  echo "$(date) | This script has run already. Exiting."
  exit 0

fi

while [[ $ready -ne 1 ]];do

  # If we've waited for too long, we should just carry on
  if [[ $(($(date +%s) - $START)) -ge $secondsToWaitForOtherApps ]]; then
      echo "$(date) | Waited for [$secondsToWaitForOtherApps] seconds, continuing anyway]"
      break
  fi

  missingappcount=0

  for i in "${dockapps[@]}"; do
    if [[ -a "$i" ]]; then
      echo "$(date) |  $i is installed"
    else
      let missingappcount=$missingappcount+1
    fi
  done

  echo "$(date) |  [$missingappcount] application missing"
  updateSplashScreen wait "En attente de $missingappcount applications..."


  if [[ $missingappcount -eq 0 ]]; then
    ready=1
    echo "$(date) |  All apps found, lets reboot this machine."
  else
    echo "$(date) |  Waiting for 10 seconds"
    sleep 10
  fi

done

# Compte à rebours pour le redémarrage
#for (( i=30; i>=0; i-- )); do
#    updateSplashScreen wait "Redémarrage dans $i secondes..."
#    sleep 1  # Wait for 1 second
#done

updateSplashScreen wait "Redémarrage..."
sleep 30

# Ajout d'un flag sur le poste pour dire que nous avons redémarré
touch /var/tmp/rebootedAfterSetup
touch '/Library/Application Support/Microsoft/IntuneScripts/Swift Dialog/onboarding.flag'

# Redémarrage du poste
sudo shutdown -r now
